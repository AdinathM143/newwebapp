from django.contrib import admin

from Home.models import Entry

# Register your models here.
admin.site.register(Entry)
# Register your models here.
